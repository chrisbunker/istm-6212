#A filter that removes stop words.

import fileinput
import re


def formula(line):
    #For each line of input, split all words that are followed by a space.
    return(line.strip())

stopwords = ["and", "the", "to", "of", "her", "it", "in", "you", "she", "for", "was", "as", "that", "with", "he", "but", "so", "his", "at", "had", "be", "on", "not", "if"]

for line in fileinput.input():
    words = re.split(r'\W+', formula(line))
    for word in words:
        if word not in stopwords:
            print(word)